package EBI01286.rajesh;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class App {
	private static final String OUTPUT_FILE1 = "REPORT.TXT";
	private static final String OUTPUT_FILE2 = "SEQUENCE.FASTA";
	private static final String OUTPUT_FILE2_GZ = "SEQUENCE.FASTA.GZ";
	private static final String INPUT_FILE_FORMAT = ".fasta";

	public static void main(String[] args) throws IOException {
		if (args != null && args.length>0) {
			String[] files = new String[args.length - 1];
			for (int i = 0; i < args.length - 1; i++) {
				if (args[i].contains(".gz")) {
					files[i] = args[i];
				} else {
					System.out.println("Please provide only .gz files.");
					return;
				}
			}

			if (!(args[args.length - 1].matches("[0-9]+"))) {
				System.out.println("Please provide number of threads and in numeric.");
				return;
			}

			ExecutorService executorService = Executors.newFixedThreadPool(Integer.parseInt(args[args.length - 1]));
			executorService.submit(() -> {
				try {
					task(files);
				} catch (IOException e) {
					System.out.println("Exception while performing Task: "+e.getMessage());
				}
			});
			executorService.shutdown();
			System.out.println("Task is completed..!");
		} else {
			System.out.println("Please provide arguments (one or more gzip compressed Fasta files and number of worker threads)");
		}
	}

	private static void task(String[] files) throws IOException {
		String[] params = files;
		if (params.length < 1)
			System.out.println("Please provide valid parameters");

		StringBuffer completeData = new StringBuffer();

		for (String param : params) {
			FileInputStream fileIn = new FileInputStream(param);
			GZIPInputStream gZIPInputStream = new GZIPInputStream(fileIn);

			byte[] readBuffer = new byte[5000];
			int read = gZIPInputStream.read(readBuffer, 0, readBuffer.length);
			
			gZIPInputStream.close();

			byte[] result = Arrays.copyOf(readBuffer, read);

			String fileData = new String(result, "UTF-8");
			completeData.append(fileData);
			
			gZIPInputStream.close();
			fileIn.close();
		}

		String data = completeData.toString();
		writeFileCount(data);
		writeSequenceCount(data);
		writeBaseCountAndCharCount(data);
		System.out.println("created " + OUTPUT_FILE1 + " File successfully..!");

		writeSequenceFastaFile(data);	
	}

	/**
	 * Write SEQUENCE.FASTA file
	 * 
	 * @param data
	 */
	private static void writeSequenceFastaFile(String data) {
		Map<Integer, StringBuffer> resultMap = loadFilestoMap(data, "\n");

		Iterator<Entry<Integer, StringBuffer>> Itr = resultMap.entrySet().iterator();
		while (Itr.hasNext()) {
			Map.Entry<Integer, StringBuffer> entry = (Map.Entry<Integer, StringBuffer>) Itr.next();
			String key = ">" + String.valueOf(entry.getKey());
			String value = entry.getValue() != null ? entry.getValue().toString() : "";
			writeOutputFile(OUTPUT_FILE2, key, value);
		}
		System.out.println("created " + OUTPUT_FILE2 + " File successfully..!");
		createSequenceFastagzipFile(OUTPUT_FILE2, OUTPUT_FILE2_GZ);
	}

	/**
	 * 
	 * @param gzipString
	 *            Load input files to Map
	 * @param format
	 *            format to split the file
	 * @return
	 */
	private static Map<Integer, StringBuffer> loadFilestoMap(String gzipString, String format) {
		Map<Integer, StringBuffer> fileValueMap = new ConcurrentHashMap<Integer, StringBuffer>();

		String[] parts = gzipString.split(format);
		Integer key = 0;
		for (String line : parts) {
			line = line.trim();
			if (line != null && !("".equals(line))) {
				if (line.indexOf(INPUT_FILE_FORMAT) != -1) {
					key = 0;
				}
				if (line.indexOf(">") != -1) {
					key++;
					if (fileValueMap.get(key) == null)
						fileValueMap.put(key, new StringBuffer());
				} else {
					fileValueMap.get(key).append(line.substring(0));
				}
			}
		}
		return fileValueMap;
	}

	/**
	 * Write FILE_CNT
	 * 
	 * @param message
	 */
	private static void writeFileCount(String line) {
		writeOutputFile(OUTPUT_FILE1, "FILE_CNT", countForPatternMatch(line, INPUT_FILE_FORMAT));
	}

	/**
	 * write SEQUENCE_CNT
	 * 
	 * @param message
	 */
	private static void writeSequenceCount(String line) {
		writeOutputFile(OUTPUT_FILE1, "SEQUENCE_CNT", countForPatternMatch(line, ">"));
	}

	/**
	 * Write BASE_CNT total number of sequence bases and each total number of
	 * sequence base character count
	 * 
	 * @param message
	 *            data of sequence base
	 */
	private static void writeBaseCountAndCharCount(String line) {
		Map<String, String> resultMap = loadSequencestoMap(line, "\n");
		writeBaseCount(resultMap);

		Iterator<Entry<String, String>> Itr = resultMap.entrySet().iterator();
		String dataCharCount = "";
		while (Itr.hasNext()) {
			Map.Entry<String, String> entry = (Map.Entry<String, String>) Itr.next();
			dataCharCount = dataCharCount + entry.getValue();
		}
		writeCharCount(dataCharCount);
	}

	/**
	 * WriteBaseCount(total number of sequence bases) to output file
	 * 
	 * @param resultMap
	 *            that contains Fasta files data
	 */
	private static void writeBaseCount(Map<String, String> resultMap) {
		Iterator<Entry<String, String>> Itr = resultMap.entrySet().iterator();
		int valueLength = 0;
		while (Itr.hasNext()) {
			Map.Entry<String, String> entry = (Map.Entry<String, String>) Itr.next();
			valueLength = valueLength + entry.getValue().length();
		}
		writeOutputFile(OUTPUT_FILE1, "BASE_CNT", String.valueOf(valueLength));
	}

	/**
	 * WriteCharCount to output file
	 * 
	 * @param line
	 *            sequence base
	 */
	private static void writeCharCount(String line) {
		Map<Character, Integer> map = new ConcurrentHashMap<Character, Integer>();
		int value = 0;
		for (int i = 0; i < line.length(); i++) {
			if (map.containsKey(line.charAt(i))) {
				value = map.get(line.charAt(i));
				value++;
				map.put(line.charAt(i), value);
			} else {
				map.put(line.charAt(i), 1);
			}
		}
		for (Character key : map.keySet()) {
			// System.out.println("Character : '"+key+"' Count :"+map.get(key));
			String character = String.valueOf(key);
			String count = String.valueOf(map.get(key));
			writeOutputFile(OUTPUT_FILE1, character, count);
		}
	}

	/**
	 * Load Fasta files data to map
	 * 
	 * @param gzipString
	 *            gzip file
	 * @param format
	 *            split the file contents based on format
	 * @return
	 */
	private static Map<String, String> loadSequencestoMap(String gzipString, String format) {
		Map<String, String> seqValueMap = new ConcurrentHashMap<String, String>();
		String[] parts = gzipString.split(format);
		String key = "";
		for (String line : parts) {
			line = line.trim();
			if (line != null && !("".equals(line))) {
				if (line.indexOf(">") != -1) {
					// System.out.printf("%s ", line.substring(line.indexOf(">")+1));
					key = line.substring(line.indexOf(">") + 1);
					seqValueMap.put(key, "");
				} else {
					// System.out.printf("%s ", line.substring(1));
					seqValueMap.put(key, line.substring(1));
				}
			}
		}
		return seqValueMap;
	}

	/**
	 * Count the words that matches the format
	 * 
	 * @param gzipString
	 *            input file that contains data
	 * @param format
	 *            which need to search in gzipString
	 * @return
	 */
	private static String countForPatternMatch(String gzipString, String format) {
		int file_count = 0;
		Pattern p = Pattern.compile(format);
		Matcher m = p.matcher(gzipString);
		while (m.find()) {
			file_count++;
		}
		return String.valueOf(file_count);
	}

	/**
	 * Write data to output file REPORT.TXT
	 * 
	 * @param data1
	 *            key in output file
	 * @param data2
	 *            value in output file
	 */
	private static void writeOutputFile(String fileName, String data1, String data2) {
		File file = new File(fileName);
		FileWriter fr = null;
		BufferedWriter br = null;
		try {
			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			br.write(data1);
			if (OUTPUT_FILE2.equalsIgnoreCase(fileName))
				br.write("\n");
			else
				br.write("\t");
			br.write(data2);
			br.write("\n");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Write SEQUENCE.FASTA.GZ file
	 * 
	 * @param seqFile
	 * @param gzFileName
	 */
	public static void createSequenceFastagzipFile(String seqFile, String gzFileName) {
		byte[] buffer = new byte[1024];
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(gzFileName);
			GZIPOutputStream gzipOuputStream = new GZIPOutputStream(fileOutputStream);
			FileInputStream fileInput = new FileInputStream(seqFile);

			int bytes_read;

			while ((bytes_read = fileInput.read(buffer)) > 0) {
				gzipOuputStream.write(buffer, 0, bytes_read);
			}
			fileInput.close();
			gzipOuputStream.finish();
			gzipOuputStream.close();
			System.out.println("created " + OUTPUT_FILE2_GZ + " File successfully..!");
		} catch (IOException ex) {
			ex.printStackTrace();

		}
	}
}
